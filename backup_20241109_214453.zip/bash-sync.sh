#!/bin/bash

# Caminhos padrão
SERVER_PATH="/root/correios"
LOCAL_PATH="."

# Lista de servidores com IP e porta
SERVERS=(
    "Server 4N|101.99.75.122:20203"  # Nome do servidor | IP e Porta
    "Server 12N|111.90.148.166:20203"
    "Server TIO|148.113.178.203:22"
)

# Variáveis para IP e porta
SERVER_IP=""
SERVER_PORT=""

# Função para escolher o servidor
choose_server() {
    echo "====== Escolha o Servidor ======"
    PS3="Selecione o servidor: "
    
    # Cria a lista apenas com os nomes para o menu
    server_names=()
    for entry in "${SERVERS[@]}"; do
        server_names+=("$(echo "$entry" | cut -d'|' -f1)")
    done

    select server_name in "${server_names[@]}"; do
        if [[ -n "$server_name" ]]; then
            selected_entry="${SERVERS[$((REPLY - 1))]}"
            SERVER_IP=$(echo "$selected_entry" | cut -d'|' -f2 | cut -d':' -f1)
            SERVER_PORT=$(echo "$selected_entry" | cut -d'|' -f2 | cut -d':' -f2)
            echo "Servidor selecionado: $server_name ($SERVER_IP:$SERVER_PORT)"
            break
        else
            echo "Opção inválida. Tente novamente."
        fi
    done
}

# Função para sincronizar do servidor para o PC
sync_server_to_pc() {
    if [[ -z "$SERVER_IP" || -z "$SERVER_PORT" ]]; then
        echo "Nenhum servidor selecionado. Use a opção 3 para selecionar um servidor."
        return
    fi
    echo "Sincronizando do servidor para o PC..."
    rsync -avz --progress -e "ssh -p ${SERVER_PORT}" "${SERVER_USER}@${SERVER_IP}:${SERVER_PATH}/" "${LOCAL_PATH}/"
    echo "Sincronização do servidor para o PC concluída!"
}

# Função para sincronizar do PC para o servidor
sync_pc_to_server() {
    if [[ -z "$SERVER_IP" || -z "$SERVER_PORT" ]]; then
        echo "Nenhum servidor selecionado. Use a opção 3 para selecionar um servidor."
        return
    fi
    echo "Sincronizando do PC para o servidor..."
    rsync -avz --progress -e "ssh -p ${SERVER_PORT}" "${LOCAL_PATH}/" "${SERVER_USER}@${SERVER_IP}:${SERVER_PATH}/"
    echo "Sincronização do PC para o servidor concluída!"
}

#
backup_local() {
    echo "Criando backup da pasta local..."
    
    # Nome do arquivo de backup com timestamp
    BACKUP_NAME="backup_$(date +%Y%m%d_%H%M%S).zip"
    
    # Comando para criar o ZIP ignorando as pastas específicas
    zip -r "${BACKUP_NAME}" . -x "venv/*" "flask_session/*" "__pycache__/*" "*/__pycache__/*" "*/venv/*" "*/flask_session/*"

    echo "Backup concluído: ${BACKUP_NAME}"
}


# Menu interativo
while true; do
    clear
    echo "====== Menu de Sincronização ======"
    echo "1. Sync SERVER => LOCAL"
    echo "2. Sync LOCAL => SERVER"
    echo "3. SELECIONAR SERVIDOR"
    echo "4. BACKUP LOCAL ZIP"
    echo "5. Sair"
    echo "==================================="
    read -p "Escolha uma opção: " option
    
    case $option in
        1) 
            sync_server_to_pc
            read -p "Pressione Enter para continuar..."
            ;;
        2) 
            sync_pc_to_server
            read -p "Pressione Enter para continuar..."
            ;;
        3)
            choose_server
            read -p "Pressione Enter para continuar..."
            ;;
        4) 
            backup_local
            read -p "Pressione Enter para continuar..."
            ;;
        5) 
            echo "Saindo..."
            exit 0
            ;;
        *) 
            echo "Opção inválida! Tente novamente."
            read -p "Pressione Enter para continuar..."
            ;;
    esac
done
